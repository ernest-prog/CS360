package com.example.module5assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TextWatcher {
    EditText nameText;
    TextView textGreeting;
    Button buttonSayHello;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        nameText.addTextChangedListener(this);
        buttonSayHello.setEnabled(false);
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    public void afterTextChanged(Editable s) {
        buttonSayHello.setEnabled(!nameText.getText().toString().matches(""));
    }
    @SuppressLint("SetTextI18n")
    public void SayHello(View view)
    {
        if(!nameText.getText().toString().matches(""))
        {
            textGreeting.setText("Hello "+nameText.getText());
        }
        else
        {
            textGreeting.setText("You must enter a name");
        }
    }

}