package com.example.finalproject;

import static java.lang.Long.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DatabaseInformation extends AppCompatActivity {

    Button btnAddPressed;
    Button btnEditItem;
    Button btnSettings;
    Button btnDelete;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_information);

        btnAddPressed = (Button) findViewById(R.id.Add);
        btnAddPressed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DatabaseInformation.this, AddActivity.class);
                startActivity(intent);
            }
        });
        btnEditItem = (Button)findViewById(R.id.editItem);
        btnEditItem.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(DatabaseInformation.this, UpdateActivity.class);
                startActivity(intent);
            }
        });

        btnSettings = (Button)findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(DatabaseInformation.this, Settings.class);
                startActivity(intent);
            }
        });
        btnDelete= (Button)findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(DatabaseInformation.this, UpdateActivity.class);
                startActivity(intent);
            }
        });
    }
}

